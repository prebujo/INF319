package functions.utility;

import dataObjects.IDataSet;
import functions.feasibility.IFeasibility;

import java.util.Random;

public class RemoveDifferentClusterInsertSimilarCluster extends RemoveAndReinsert{

    public RemoveDifferentClusterInsertSimilarCluster(String name, int lowerLimit, int upperLimit, Random random, IFeasibility feasibilityCheck, IDataSet dataSet) {
        super(name, lowerLimit, upperLimit, random, feasibilityCheck, dataSet);
    }

    @Override
    public int[] apply(int[] solution) throws Throwable {
        return new int[0];
    }
}
