package dataObjects;

public interface IDataObject {
    Object getData();
    void setData(Object object);
}
