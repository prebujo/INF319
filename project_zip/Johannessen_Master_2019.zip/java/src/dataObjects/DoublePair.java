package dataObjects;

public class DoublePair {
    public double firstDouble;
    public double secondDouble;
    public DoublePair(double firstDouble,double secondDouble){
        this.firstDouble = firstDouble;
        this.secondDouble=secondDouble;
    }
}
